"use strict";
// enum for User Roles//enum
var UserRole;
(function (UserRole) {
    UserRole["Admin"] = "admin";
    UserRole["Manager"] = "manager";
    UserRole["Employee"] = "employee";
})(UserRole || (UserRole = {}));
const newUSer = {
    id: 101,
    name: "Sandhya",
    email: "sandhya@gmail.com",
    role: UserRole.Admin,
    phoneNumber: "9876543210"
};
const newUSer1 = {
    id: 102,
    name: "Rutuja",
    email: "rutuja@gmail.com",
    role: UserRole.Manager,
    phoneNumber: "1023456789"
};
const newUSer2 = {
    id: 103,
    name: "Neha",
    email: "neha@gmail.com",
    role: UserRole.Employee,
};
// Function to create a User object
function createUser(user) {
    return user;
}
// Function to filter users based on roles
function getUsersByRoles(users, roles) {
    return users.filter(user => roles.includes(user.role));
}
// List of users
const users = [newUSer, newUSer1, newUSer2];
// Filter users based on Admin and Manager roles
let AdminsManagers = getUsersByRoles(users, [UserRole.Admin, UserRole.Manager]);
console.log(AdminsManagers);
