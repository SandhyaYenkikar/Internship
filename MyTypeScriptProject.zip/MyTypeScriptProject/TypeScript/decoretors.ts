// Class Decorator
// function ClassDecorator (target: Function, contex: ClassDecoratorContext){
//     //perform actions or modify 
// }

// function logClass(target: any): void {
//     console.log(target);
//    // console.log(context);
// }

// @logClass
// class MyClass {

// }



// Method Decorator
// function logMethod(
//     target: Object,
//     propertyKey: string | symbol,
//     descriptor: PropertyDescriptor
// ) {
//     const originalMethod = descriptor.value;

//     descriptor.value = function (...args: any[]) {
//         console.log(`Method: ${String(propertyKey)}`);
//         console.log('Arguments:', args);
//         const result = originalMethod.apply(this, args);
//         console.log('Result:', result);
//         return result;
//     };

//     return descriptor;
// }

// // Applying the decorator
// class ExampleClass {
//     constructor() {
//         console.log('ExampleClass instantiated');
//     }

//     @logMethod
//     exampleMethod(a: number, b: number): number {
//         return a + b;
//     }
// }

// // Creating an instance and calling the method
// const example = new ExampleClass();
// example.exampleMethod(5, 10);

// Method Decorator
// function logMethod(
//     target: Object,
//     propertyKey: string | symbol, //name of method
//     descriptor: PropertyDescriptor
// ) {
//     const originalMethod = descriptor.value;

//     descriptor.value = function (...args: any[]) {
//         console.log(`Method: ${String(propertyKey)}`);
//         return originalMethod.apply(this, args);
//     }
// }
// Method Decoretors example 2
// function logClass(target:Function){
//     console.log("target " +target.name)
// }

// function logMethod(target:any, propertyKey:string,descriptor:PropertyDescriptor){
//     console.log("Method")
// }

// @logClass
// class MyClass{
//     @logMethod
//     myMethod(){
//         console.log("ssssssssssssss")
//     }
// }

// Accessor Decorators - applied to getter or setter
// Property Decoretors - change the behaviour of propperty
// function logProperty (
//         traget: Object,
//         propertyKey: string | symbol        
// ) {
//     console.log(`Property ${String(propertyKey)} has been decorated`)
// }
// class MyClass{
//     @logProperty
//     name: string;
//     constructor(name:string){
//         this.name=name;
//     }
// }

// //Parameter Decorators
// function logParameter( target:object, propertyKey:number, parameterIndex: number)

// {
//     console.log("VAlue added")
// }
// class MyClass{
//     greet(@logParameter name:string){

//     }
// }

// Parameter Decorator
// function logParameter(target: Object, propertyKey: string | symbol, parameterIndex: number) {
//     console.log(`Decorated parameter at index ${parameterIndex} for method ${String(propertyKey)}`);
// }

// class MyClass {
//     greet(@logParameter name: string) {
//         console.log(`Hello, ${name}!`);
//     }
// }

// // Creating an instance and calling the method
// const myClassInstance = new MyClass();
// myClassInstance.greet('World');

// Replacing a class 
// function ReplaceWithProxy<T extends { new (...args: any[]): {} }>(constructor: T) {
//     return class extends constructor {
//         proxyEnabled = true;
//     };
// }

// @ReplaceWithProxy
// class Order {
//     constructor(public id: number, public amount: number) {}
// }

// const order = new Order(1, 500) as Order & {proxyEnabled:boolean}
// console.log(order.proxyEnabled); // Outputs: true
//Role based access control
// Class Decorator
function Authorize(role: string) {
    return function (constructor: any) {
        constructor.prototype.role = role;
        console.log(`Authorization role set to: ${role} for ${constructor.name}`);
    }
}

@Authorize('admin')
class AdminPanel {
    role?: string;

    constructor() {
        console.log('AdminPanel instantiated');
    }

    approveRequest(requestId: number) {
        if (this.isAuthorized()) {
            console.log(`Request ${requestId} approved.`);
        } else {
            console.log(`Unauthorized to approve request ${requestId}.`);
        }
    }

    private isAuthorized(): boolean {
        // Example check for the sake of demonstration
        return this.role === 'admin';
    }
}

// Example usage
const adminPanel = new AdminPanel();
adminPanel.approveRequest(42);
