// class Person{
//     name: string;
//     age: number;
//  //Constructor initilizes class properties
//     constructor(name: string, age: number){
//         this.name = name;
//         this.age = age;
//     }
//  //method to siaplay person details
//     displayInfo(){
//         console.log(`Name: ${this.name}, Age: ${this.age}`);
//     }
// }
//  //creating objects
//     const person1 = new Person("Sandhya Yenkikar", 30);
//     person1.displayInfo(); 