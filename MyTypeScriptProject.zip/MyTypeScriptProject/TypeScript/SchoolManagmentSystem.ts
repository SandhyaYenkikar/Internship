// Base class Person //classes
class Person {
    public name: string;
    public age: number;

    constructor(name: string, age: number) {
        this.name = name;
        this.age = age;
    }

    introduce(): string {
        return `Hi, my name is ${this.name} and I am ${this.age} years old.`;
    }
}

// Derived class Student
class Student extends Person {
    private static totalStudents: number = 0;
    private readonly grade: number;
    public studentId: string;

    constructor(name: string, age: number, grade: number, studentId: string) {
        super(name, age);
        this.grade = grade;
        this.studentId = studentId;
        Student.totalStudents++;
    }

    introduce(): string {
        return `Hi, I am ${this.name}, a student in grade ${this.grade}.`;
    }

    static getTotalStudents(): number {
        return Student.totalStudents;
    }
}

// Derived class Teacher
class Teacher extends Person {
    private static totalTeachers: number = 0;
    private readonly subject?: string;

    constructor(name: string, age: number, subject?: string) {
        super(name, age);
        this.subject = subject;
        Teacher.totalTeachers++;
    }

    introduce(): string {
        return `Hi, I am ${this.name} and I teach ${this.subject}.`;
    }

    static getTotalTeachers(): number {
        return Teacher.totalTeachers;
    }
}

// Abstract class Staff
abstract class Staff {
    public department: string;

    constructor(department: string) {
        this.department = department;
    }

    abstract workDetails(): string;
}

// Derived class Clerk
class Clerk extends Staff {
    private readonly responsibility: string = 'Managing attendance records';

    private salary: number;

    constructor( department: string, salary: number) {
        super(department);
        this.department=department;
        this.salary = salary;
      //  Clerk.totalClerks++;
    }

    workDetails(): string {
        return `I  am Clerk work in the ${this.department} department, responsibility is ${this.responsibility}.`;
    }
}

// Creating instances
const student = new Student('Sandhya', 18, 10, 'STU123');
const teacher = new Teacher('Rutuja', 27, 'Java');
const student1 = new Student('Aishwarya', 19, 12, 'STU124');
const teacher1 = new Teacher('Prachi', 27, 'Web Devlopment');
const clerk = new Clerk('Account', 50000);

// Display their introductions
console.log(student.introduce());
console.log(teacher.introduce());
console.log(student1.introduce());
console.log(teacher1.introduce());

// Display total count of students and teachers
console.log(`Total Students: ${Student.getTotalStudents()}`);
console.log(`Total Teachers: ${Teacher.getTotalTeachers()}`);

// Call workDetails method of clerk
console.log(clerk.workDetails());
