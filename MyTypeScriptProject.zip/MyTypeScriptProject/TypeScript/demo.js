"use strict";
// //Data Types
// let num1:number=12;
// let empName:string="Sandhya";
// let empNamee:null;
// let empName1:undefined;
// console.log(num1, empName, empNamee, empName1);
// //Array
// //fixed size
// let arr:number[]=[1,2,3];
// console.log(arr);
// //dynamic
// let arrr:number[]=[1,2,3,4,5];
// console.log(arrr);
// arrr.push(12)
// console.log(arrr);
//Tuple (used only for fixed value)
// let person:[string, number] = ["Alice",30];
// console.log(person);
// //object
// //let user:{id:number;userName:string}={id:101,userName:"Sandhya"};
// //.log(user);
// //Union and Intersection
// //union = hold number or string
// let empID:number|string;
// empID=101;
// empID="EMP105"
// console.log(empID);
// //intersection = holds number and string
// interface Address {
//     city:string;
//     postalCode:number;
// }
// interface Coordinates{
//     latitude:number;
//     longitude:number;
// }
// type location = Address & Coordinates;
// let myLocation: location = {
//     city: "Mumbai",
//     postalCode: 413004,
//     latitude: 40.7123,
//     longitude: -74.006,
// };
// console.log(myLocation);
// //alises
// type ID=number|string;
// let empIDd:ID;
// empIDd=101;
// console.log(empIDd);
// empIDd="emp101";
// console.log(empIDd);
// //Literal Types -directions
// type direction="up"|"down"|"left"|"right";
// let dir:direction;
// dir="up";
// console.log(dir);
// //Interfaces= provides a structure for object
// interface User {
//     id:number;
//     name:string;
//     email:string;
// }
// const user:User = {id:2005, name:"Sandhya",email:"sandhya@gail.com"};
// console.log(user);
// //optional properties
// /*interface Userr {
//     id:number;
//     name:string;
//     email?:string;
//     const Userr:Userr = {id:2005, name:"Sandhya"};
//     console.log(userr);
// }*/
// //read only property
// //extending interfaces = allows inheritance from interfcaes
// interface Person{
//     name:string;
// }
// interface Employee extends Person{
//     employeeID:number;
// }
// const employee: Employee = {name:"Sandhya",employeeID:11};
// console.log(employee);
//Enums 
//Functions
// //typed parameters and return types,
// function add(num1:number,num2:number):number{
//     return num1+num2;
// }
//console.log(add(12,30));
//  function add(num1:number,num2:number=5,num3:number=0 ):number{
//      return num1+num2+num3
//  }
//  console.log(add(12,undefined,20));
//optional
//  function myFunction(id:number, name:string, email?:string):void{
//     console.log(id,name,email);
//  }
//     myFunction(1,"Sandhya");
//arrow function = one line function
//const myFunction = (id: number, name: string, email?: string): void => {
//   console.log(id, name, email); }; 
// myFunction(1, "Sandhya");
//function overloading - fun have same name, diff parameters, priority of any is high.
//function combine(a:string, b:string): string;
//function combine(a:number, b:number): number;
//function combine(a:any, b:any): any{
//  return a+b;
//}
//console.log(combine(10,20));
//generics - reusability and type safety for functions,classes and interfaces.
//generic functions
// function identity<T> (value:T):T{
//     return value;
// }
// console.log(identity<number>(10));
// console.log(identity<string>("Hello"));
//generic classes
// class Box<T>{
//     private content: T;
//     constructor(content:T){
//         this.content = content;
//     }
//     getContent(): T{
//         return this.content;
//     }
// }
// const stringBox = new Box<string>("TypeScript");
// console.log(stringBox.getContent());
//generic interfacces
// interface KeyValuePair <K,V> {
//     key: K;
//     value: V;
// }
// const pair: KeyValuePair<string, number> = {key: "age", value: 30};
// const pair1: KeyValuePair<string, number> = {key: "KeyValue", value: 10};
// console.log(pair);
// console.log(pair1);
//eventlisteners
const handleEvent = (event) => {
    //event handling logic
};
//attach the event lsiteners
Element.addEventListener('click', handleEvent);
//optional: remove the event lsiteners
