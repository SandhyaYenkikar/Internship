//Typescript function  using generics that accepts an array and a type and return the last element.

// function getLastElement<T>(arr: T[]): T | undefined {
//     return arr.length > 0 ? arr[arr.length - 1] : undefined;
// }

// const numbers = [1, 2, 3, 4, 5];
// const lastNumber = getLastElement(numbers);  

// console.log("Given Numbers =",numbers);
// console.log("Last Number",lastNumber);


//Question 2

// interface Product {
//     id: number;
//     name: string;
//     price: number;
// }

// function displayProductDetails(product: Product): void {
//     console.log("Product ID: ", product.id);
//     console.log("Product Name: ", product.name);
//     console.log("Product Price: ", product.price);

// }


// const exampleProduct: Product = {
//     id: 1,
//     name: "Mobile",
//     price: 75000
// };

// displayProductDetails(exampleProduct);

//Question 3
enum OrderStatus {
    Pending = "Pending",
    Shipped = "Shipped",
    Delivered = "Delivered"
}

interface Order {
    id: number;
    status: OrderStatus;
}

function handleOrderStatus(order: Order): void {
    switch (order.status) {
        case OrderStatus.Pending:
            console.log("Your order is pending. Please wait.");
            break;
        case OrderStatus.Shipped:
            console.log("Your order has been shipped. It will arrive soon.");
            break;
        case OrderStatus.Delivered:
            console.log("Your order has been delivered. Enjoy!");
            break;
        default:
            console.log("Unknown order status.");
    }
}
const exampleOrder: Order = {
    id: 3,
    status: OrderStatus.Shipped
};

handleOrderStatus(exampleOrder);


