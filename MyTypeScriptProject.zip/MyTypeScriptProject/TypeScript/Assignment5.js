var __runInitializers = (this && this.__runInitializers) || function (thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for (var i = 0; i < initializers.length; i++) {
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
};
var __esDecorate = (this && this.__esDecorate) || function (ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) { if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected"); return f; }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for (var i = decorators.length - 1; i >= 0; i--) {
        var context = {};
        for (var p in contextIn) context[p] = p === "access" ? {} : contextIn[p];
        for (var p in contextIn.access) context.access[p] = contextIn.access[p];
        context.addInitializer = function (f) { if (done) throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
        var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        }
        else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
};
// Step 1: Define the User Model
var User = /** @class */ (function () {
    function User(id, name, role) {
        this.id = id;
        this.name = name;
        this.role = role;
    }
    return User;
}());
// Step 2: Define Permissions
var rolePermissions = {
    admin: ['view', 'edit', 'delete'],
    manager: ['view', 'edit'],
    employee: ['view'],
};
// Step 3: Create an Access Control Decorator
function authorize(action) {
    return function (target, propertyKey, descriptor) {
        var originalMethod = descriptor.value;
        descriptor.value = function () {
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                args[_i] = arguments[_i];
            }
            var user = args[0];
            if (rolePermissions[user.role] && rolePermissions[user.role].includes(action)) {
                return originalMethod.apply(this, args);
            }
            else {
                console.error("[Access Denied] User ".concat(user.name, " (Role: ").concat(user.role, ") is not allowed to ").concat(action));
                return null;
            }
        };
        return descriptor;
    };
}
// Test Scenarios
var ReportActions = function () {
    var _a;
    var _instanceExtraInitializers = [];
    var _viewReport_decorators;
    var _editReport_decorators;
    var _deleteReport_decorators;
    return _a = /** @class */ (function () {
            function ReportActions() {
                __runInitializers(this, _instanceExtraInitializers);
            }
            ReportActions.prototype.viewReport = function (user) {
                console.log("".concat(user.name, " is viewing the report."));
            };
            ReportActions.prototype.editReport = function (user) {
                console.log("".concat(user.name, " is editing the report."));
            };
            ReportActions.prototype.deleteReport = function (user) {
                console.log("".concat(user.name, " is deleting the report."));
            };
            return ReportActions;
        }()),
        (function () {
            var _metadata = typeof Symbol === "function" && Symbol.metadata ? Object.create(null) : void 0;
            _viewReport_decorators = [authorize('view')];
            _editReport_decorators = [authorize('edit')];
            _deleteReport_decorators = [authorize('delete')];
            __esDecorate(_a, null, _viewReport_decorators, { kind: "method", name: "viewReport", static: false, private: false, access: { has: function (obj) { return "viewReport" in obj; }, get: function (obj) { return obj.viewReport; } }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(_a, null, _editReport_decorators, { kind: "method", name: "editReport", static: false, private: false, access: { has: function (obj) { return "editReport" in obj; }, get: function (obj) { return obj.editReport; } }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(_a, null, _deleteReport_decorators, { kind: "method", name: "deleteReport", static: false, private: false, access: { has: function (obj) { return "deleteReport" in obj; }, get: function (obj) { return obj.deleteReport; } }, metadata: _metadata }, null, _instanceExtraInitializers);
            if (_metadata) Object.defineProperty(_a, Symbol.metadata, { enumerable: true, configurable: true, writable: true, value: _metadata });
        })(),
        _a;
}();
// Test Cases
var adminUser = new User(1, 'Alice', 'admin');
var managerUser = new User(2, 'Bob', 'manager');
var employeeUser = new User(3, 'Charlie', 'employee');
var reportActions = new ReportActions();
reportActions.viewReport(adminUser);
reportActions.editReport(adminUser);
reportActions.deleteReport(adminUser);
reportActions.viewReport(managerUser);
reportActions.editReport(managerUser);
reportActions.deleteReport(managerUser);
reportActions.viewReport(employeeUser);
reportActions.editReport(employeeUser);
reportActions.deleteReport(employeeUser);
