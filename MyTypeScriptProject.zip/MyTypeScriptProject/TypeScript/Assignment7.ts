enum Roles {
    Manager = "Manager",
    Developer = "Developer",
    Intern = "Intern"
}

enum Status {
    Active = "Active",
    Inactive = "Inactive"
}

interface Employee {
    id: number;
    name: string;
    role: Roles;
    status: Status;
}

const employees: Employee[] = [];  // employee empty array

// function to get an employee by ID
function getEmployeeById(id: number): Employee | undefined {
    return employees.find(emp => emp.id === id);
}

// Add a new employee to the list
function addEmployee(employee: Employee): void {
    employees.push(employee); 
}

type EmployeeUpdates = Partial<Pick<Employee, 'status'>>;

// Update the status of an employee
function updateEmployee(id: number, updates: EmployeeUpdates): void {
    const employee = getEmployeeById(id);
    if (employee) {
        Object.assign(employee, updates);
    }
}

// Generate summaries of all employees
function generateEmployeeSummaries(): Array<{ name: string; role: Roles; status: Status }> {
    return employees.map(e => ({ name: e.name, role: e.role, status: e.status }));
}

// Group employees by their role
function groupEmployeesByRole(): Record<Roles, Employee[]> {
    const employeeGroups: Record<Roles, Employee[]> = {
        [Roles.Manager]: [],
        [Roles.Developer]: [],
        [Roles.Intern]: []
    };

    employees.forEach(employee => {
        employeeGroups[employee.role].push(employee);
    });

    return employeeGroups;
}

// Adding employees
addEmployee({ id: 1, name: "Sandhya", role: Roles.Manager, status: Status.Active });
addEmployee({ id: 2, name: "Rutuja", role: Roles.Developer, status: Status.Active });
addEmployee({ id: 3, name: "Neha", role: Roles.Intern, status: Status.Inactive });

// Updating an employee's status
updateEmployee(3, { status: Status.Active });

// Generating and displaying employee summaries
const summaries = generateEmployeeSummaries();
console.log("Employee Summaries:", summaries);

// Grouping employees by role 
const groupedEmployees = groupEmployeesByRole();
console.log("Grouped Employees by Role:", groupedEmployees);
// Add data in table