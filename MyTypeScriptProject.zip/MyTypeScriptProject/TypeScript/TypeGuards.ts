// typeof Type Guards
function printValue(value: string | number) {
    if (typeof value === "string") {
        console.log("String Value:", value.toUpperCase());
    } else if (typeof value === "number") {
        console.log("Number Value:", value);
    }
}

printValue("sandhya");  // Should print: String Value: STRING
printValue(42);        // Should print: Number Value: 42

////instanceof Type Guard
// class Dog{
//     bark(){
//         console.log("Woof");
//     }
// }
// class Cat{
//     meow(){
//         console.log("Meow");
//     }
// }
// function handleAnimal(animal: Dog|Cat){
//     if (animal instanceof Dog){
//         animal.bark;
//     } else if (animal instanceof Cat){
//         animal.meow();
//     }
// }
// handleAnimal(new  Dog()); //Output Woof
// handleAnimal(new  Cat()); // Output meow

// // interface Fish {
// //     swim(): void;
// // }

// // interface Bird {
// //     fly(): void;
// // }

// // function isFish(animal: Fish | Bird): animal is Fish {
// //     return (animal as Fish).swim !== undefined;
// // }

// // function handleAnimal(animal: Fish | Bird) {
// //     if (isFish(animal)) {
// //         animal.swim();
// //     } else {
// //         animal.fly();
// //     }
// // }

// // // Example usage:
// // const fish: Fish = {
// //     swim: () => console.log("The fish is swimming.")
// // };

// // const bird: Bird = {
// //     fly: () => console.log("The bird is flying.")
// // };

// // handleAnimal(fish);  // Should print: The fish is swimming.
// // handleAnimal(bird);  // Should print: The bird is flying.

// //in Opertaor
// interface Car {
//     drive(): void;
// }

// interface Boat {
//     sail(): void;
// }

// function operateVehicle(vehicle: Car | Boat) {
//     if ('drive' in vehicle) {
//         vehicle.drive();
//     } else if ('sail' in vehicle) {
//         vehicle.sail();
//     }
// }

// const car: Car = {
//     drive: () => console.log("The car is driving.")
// };

// const boat: Boat = {
//     sail: () => console.log("The boat is sailing.")
// };

// operateVehicle(car);  // Should print: The car is driving.
// operateVehicle(boat); // Should print: The boat is sailing.

// Modules and Namespaces in TypeScripts
// namespace MathOperations {
//     export function add(a: number, b: number): number {
//         return a + b;
//     }

//     export function subtract(a: number, b: number): number {
//         return a - b;
//     }
// }

// // Accessing members of the namespace
// console.log(`Add: ${MathOperations.add(10, 5)}`);      // Output: Add: 15
// console.log(`Subtract: ${MathOperations.subtract(10, 5)}`); // Output: Sub: 5
//console.log(`Substarct: ${MathOperations.substract (10,5)}`)//Output: Sub:5
