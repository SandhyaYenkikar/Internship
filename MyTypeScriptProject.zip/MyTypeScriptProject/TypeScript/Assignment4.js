"use strict";
var Role;
(function (Role) {
    Role["Manager"] = "Manager";
    Role["Developer"] = "Developer";
    Role["Intern"] = "Intern";
})(Role || (Role = {}));
var Status;
(function (Status) {
    Status["Active"] = "Active";
    Status["Inactive"] = "Inactive";
})(Status || (Status = {}));
class EmployeeManagementSystem {
    employees = new Map();
    constructor(employees) {
        this.groupEmployeesByRole(employees);
    }
    groupEmployeesByRole(employees) {
        employees.forEach(employee => {
            const roleGroup = this.employees.get(employee.role) || [];
            roleGroup.push(employee);
            this.employees.set(employee.role, roleGroup);
        });
    }
    updateEmployee(id, updates) {
        this.employees.forEach((employees, role) => {
            const employee = employees.find(emp => emp.id === id);
            if (employee) {
                Object.assign(employee, updates);
            }
        });
    }
    generateEmployeeSummary() {
        const summaries = [];
        this.employees.forEach((employees, role) => {
            employees.forEach(employee => {
                summaries.push(`Name: ${employee.name}, Role: ${employee.role}`);
            });
        });
        return summaries;
    }
}
const employees = [
    { id: 1, name: 'Alice', email: 'alice@company.com', role: Role.Manager, status: Status.Active },
    { id: 2, name: 'Bob', email: 'bob@company.com', role: Role.Developer, status: Status.Active },
    { id: 3, name: 'Charlie', email: 'charlie@company.com', role: Role.Intern, status: Status.Inactive }
];
const system = new EmployeeManagementSystem(employees);
console.log(system.generateEmployeeSummary());
system.updateEmployee(2, { email: 'bob.new@company.com' });
console.log(system.generateEmployeeSummary());
class ActivityLogger {
    activities = [];
    logActivity(activity, employee) {
        if (!this.isActive(employee)) {
            throw new Error('Cannot log activity for inactive employees.');
        }
        if (!this.isManager(employee) && activity.description === 'approve report') {
            throw new Error('Only managers can approve reports.');
        }
        this.activities.push(activity);
    }
    isActive(employee) {
        return employee.status === Status.Active;
    }
    isManager(employee) {
        return employee.role === Role.Manager;
    }
    getActivities() {
        return this.activities;
    }
}
const activityLogger = new ActivityLogger();
try {
    activityLogger.logActivity({ description: 'approve report', employeeId: 1 }, employees[0]);
    activityLogger.logActivity({ description: 'complete task', employeeId: 2 }, employees[1]);
    activityLogger.logActivity({ description: 'submit report', employeeId: 3 }, employees[2]);
}
catch (error) {
    console.error(error.message);
}
console.log(activityLogger.getActivities());
