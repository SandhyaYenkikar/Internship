"use strict";
// Base class Person //classes
class Person {
    name;
    age;
    constructor(name, age) {
        this.name = name;
        this.age = age;
    }
    introduce() {
        return `Hi, my name is ${this.name} and I am ${this.age} years old.`;
    }
}
// Derived class Student
class Student extends Person {
    static totalStudents = 0;
    grade;
    studentId;
    constructor(name, age, grade, studentId) {
        super(name, age);
        this.grade = grade;
        this.studentId = studentId;
        Student.totalStudents++;
    }
    introduce() {
        return `Hi, I am ${this.name}, a student in grade ${this.grade}.`;
    }
    static getTotalStudents() {
        return Student.totalStudents;
    }
}
// Derived class Teacher
class Teacher extends Person {
    static totalTeachers = 0;
    subject;
    constructor(name, age, subject) {
        super(name, age);
        this.subject = subject;
        Teacher.totalTeachers++;
    }
    introduce() {
        return `Hi, I am ${this.name} and I teach ${this.subject}.`;
    }
    static getTotalTeachers() {
        return Teacher.totalTeachers;
    }
}
// Abstract class Staff
class Staff {
    department;
    constructor(department) {
        this.department = department;
    }
}
// Derived class Clerk
class Clerk extends Staff {
    responsibility = 'Managing attendance records';
    salary;
    constructor(department, salary) {
        super(department);
        this.department = department;
        this.salary = salary;
        //  Clerk.totalClerks++;
    }
    workDetails() {
        return `I  am Clerk work in the ${this.department} department, responsibility is ${this.responsibility}.`;
    }
}
// Creating instances
const student = new Student('Sandhya', 18, 10, 'STU123');
const teacher = new Teacher('Rutuja', 27, 'Java');
const student1 = new Student('Aishwarya', 19, 12, 'STU124');
const teacher1 = new Teacher('Prachi', 27, 'Web Devlopment');
const clerk = new Clerk('Account', 50000);
// Display their introductions
console.log(student.introduce());
console.log(teacher.introduce());
console.log(student1.introduce());
console.log(teacher1.introduce());
// Display total count of students and teachers
console.log(`Total Students: ${Student.getTotalStudents()}`);
console.log(`Total Teachers: ${Teacher.getTotalTeachers()}`);
// Call workDetails method of clerk
console.log(clerk.workDetails());
