"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// main.ts
const TypeGuards_1 = require("./TypeGuards");
// Accessing members of the namespace
console.log(`Add: ${TypeGuards_1.MathOperations.add(10, 5)}`); // Output: Add: 15
console.log(`Subtract: ${TypeGuards_1.MathOperations.subtract(10, 5)}`); // Output: Subtract: 5
