// Build a Role Based Access Control System for a web app.
// Objective - Use TS to manage roles, permissions and user access logic.
// Key Features - Define interfaces for roles and permissions, Implement logic to
//  check user access based
// on roles, Use enums for predefined roles (e.g, Admin, Editor, Viewer).