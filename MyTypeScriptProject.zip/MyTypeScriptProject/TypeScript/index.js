//Enum for Employee Status
var EmployeeStatus;
(function (EmployeeStatus) {
    EmployeeStatus[EmployeeStatus["Active"] = 0] = "Active";
    EmployeeStatus[EmployeeStatus["Inactive"] = 1] = "Inactive";
    EmployeeStatus[EmployeeStatus["Probation"] = 2] = "Probation";
})(EmployeeStatus || (EmployeeStatus = {}));
//Function to create an employee
function createEmployee(id, name, age, status) {
    return { id: id, name: name, age: age, status: status };
}
//Funcation to display employee details.
function displayEmployee(employee) {
    console.log("ID:".concat(employee.id));
    console.log("name:".concat(employee.name));
    console.log("age:".concat(employee.age));
    console.log("Employeestatus:".concat(EmployeeStatus[employee.status]));
}
var emp1 = createEmployee(1, "Sandhya", 21, EmployeeStatus.Active);
displayEmployee(emp1);
