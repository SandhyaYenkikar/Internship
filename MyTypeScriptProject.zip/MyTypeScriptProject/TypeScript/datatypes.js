"use strict";
//Enum for Employee Status
var EmployeeStatus;
(function (EmployeeStatus) {
    EmployeeStatus[EmployeeStatus["Active"] = 0] = "Active";
    EmployeeStatus[EmployeeStatus["Inactive"] = 1] = "Inactive";
    EmployeeStatus[EmployeeStatus["Probation"] = 2] = "Probation";
})(EmployeeStatus || (EmployeeStatus = {}));
//Function to create an employee
function createEmployee(id, name, age, status) {
    return { id, name, age, status };
}
//Funcation to display employee details.
function displayEmployee(employee) {
    console.log(`ID:${employee.id}`);
    console.log(`name:${employee.name}`);
    console.log(`age:${employee.age}`);
    console.log(`Employeestatus:${EmployeeStatus[employee.status]}`);
}
const emp1 = createEmployee(1, "Sandhya", 21, EmployeeStatus.Active);
displayEmployee(emp1);
