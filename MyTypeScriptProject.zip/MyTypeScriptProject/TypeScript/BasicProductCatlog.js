"use strict";
// Define the categories as an enum
var Category;
(function (Category) {
    Category[Category["EventTarget"] = 0] = "EventTarget";
    Category[Category["Electronics"] = 1] = "Electronics";
    Category[Category["Clothing"] = 2] = "Clothing";
    Category[Category["Grocery"] = 3] = "Grocery";
})(Category || (Category = {}));
// Create an array of products
const products = [
    { productName: 'EventTarget1', price: 500, isAvailable: true, category: Category.EventTarget },
    { productName: 'Smartphone', price: 15000, isAvailable: true, category: Category.Electronics },
    { productName: 'T-Shirt', price: 500, isAvailable: false, category: Category.Clothing },
    { productName: 'Rice', price: 100, isAvailable: true, category: Category.Grocery }
];
// Display the product details in the console
products.forEach(product => {
    console.log(`Product Name: ${product.productName}`);
    console.log(`Price: ${product.price}`);
    console.log(`Available: ${product.isAvailable}`);
    console.log(`Category: ${Category[product.category]}`);
});
