"use strict";
// Enum for Book Categories
var Category;
(function (Category) {
    Category["Fiction"] = "Fiction";
    Category["NonFiction"] = "NonFiction";
    Category["Science"] = "Science";
    Category["History"] = "History";
    Category["Children"] = "Children";
})(Category || (Category = {}));
// Library Class
class Library {
    books = [];
    // Add new Book
    addBook(book) {
        if (this.books.some(b => b.id === book.id)) {
            console.log(`Book with ID ${book.id} already exists.`);
            return;
        }
        this.books.push(book);
        console.log(`Book "${book.title}" added successfully!`);
    }
    // List all books
    listBooks() {
        return this.books;
    }
    // Search by Title
    searchByTitle(title) {
        const result = this.books.filter(book => book.title.toLowerCase().includes(title.toLowerCase()));
        if (result.length) {
            console.log("Search results:");
            result.forEach(book => console.log(`ID: ${book.id}, Title: ${book.title}, Author: ${book.author}`));
        }
        else {
            console.log("No books found with the title.");
        }
    }
    // Search by Category
    searchByCategory(category) {
        const result = this.books.filter(book => book.category === category);
        if (result.length) {
            console.log("Search results:");
            result.forEach(book => console.log(`ID: ${book.id}, Title: ${book.title}, Author: ${book.author}`));
        }
        else {
            console.log("No books found in this category.");
        }
    }
    // Search by Availability
    searchByAvailability(isAvailable) {
        const result = this.books.filter(book => book.isAvailable === isAvailable);
        if (result.length) {
            console.log("Search results:");
            result.forEach(book => console.log(`ID: ${book.id}, Title: ${book.title}, Author: ${book.author}, Available: ${book.isAvailable}`));
        }
        else {
            console.log("No books found with the availability status.");
        }
    }
}
// Create Library object and test functionality
const library = new Library();
const book1 = {
    id: 1,
    title: "Littel Tinkel",
    author: "Anoymous",
    category: Category.Children,
    isAvailable: true
};
const book2 = {
    id: 2,
    title: "Cant Hurt Me",
    author: "David Gogins",
    category: Category.Fiction,
    isAvailable: true
};
library.addBook(book1);
library.addBook(book2);
console.log("Listing all books:");
console.log(library.listBooks());
console.log("Searching by title 'Littel Tinkel':");
library.searchByTitle("Littel Tinkel");
console.log("Searching by category 'Fiction':");
library.searchByCategory(Category.Fiction);
console.log("Searching by availability (true):");
library.searchByAvailability(true);
