enum Role {
    Manager = 'Manager',
    Developer = 'Developer',
    Intern = 'Intern'
}

enum Status {
    Active = 'Active',
    Inactive = 'Inactive'
}

interface Employee {
    id: number;
    name: string;
    email: string;
    role: Role;
    status: Status;
}

type UpdateEmployee = Partial<Pick<Employee, 'name' | 'email' | 'role' | 'status'>>;

class EmployeeManagementSystem {
    private employees: Map<Role, Employee[]> = new Map();

    constructor(employees: Employee[]) {
        this.groupEmployeesByRole(employees);
    }

    private groupEmployeesByRole(employees: Employee[]): void {
        employees.forEach(employee => {
            const roleGroup = this.employees.get(employee.role) || [];
            roleGroup.push(employee);
            this.employees.set(employee.role, roleGroup);
        });
    }

    public updateEmployee(id: number, updates: UpdateEmployee): void {
        this.employees.forEach((employees, role) => {
            const employee = employees.find(emp => emp.id === id);
            if (employee) {
                Object.assign(employee, updates);
            }
        });
    }

    public generateEmployeeSummary(): string[] {
        const summaries: string[] = [];
        this.employees.forEach((employees, role) => {
            employees.forEach(employee => {
                summaries.push(`Name: ${employee.name}, Role: ${employee.role}`);
            });
        });
        return summaries;
    }
}

const employees: Employee[] = [
    { id: 1, name: 'Alice', email: 'alice@company.com', role: Role.Manager, status: Status.Active },
    { id: 2, name: 'Bob', email: 'bob@company.com', role: Role.Developer, status: Status.Active },
    { id: 3, name: 'Charlie', email: 'charlie@company.com', role: Role.Intern, status: Status.Inactive }
];

const system = new EmployeeManagementSystem(employees);
console.log(system.generateEmployeeSummary());

system.updateEmployee(2, { email: 'bob.new@company.com' });
console.log(system.generateEmployeeSummary());

type Activity = {
    description: string;
    employeeId: number;
}

class ActivityLogger {
    private activities: Activity[] = [];

    public logActivity(activity: Activity, employee: Employee): void {
        if (!this.isActive(employee)) {
            throw new Error('Cannot log activity for inactive employees.');
        }

        if (!this.isManager(employee) && activity.description === 'approve report') {
            throw new Error('Only managers can approve reports.');
        }

        this.activities.push(activity);
    }

    private isActive(employee: Employee): boolean {
        return employee.status === Status.Active;
    }

    private isManager(employee: Employee): boolean {
        return employee.role === Role.Manager;
    }

    public getActivities(): Activity[] {
        return this.activities;
    }
}

const activityLogger = new ActivityLogger();

try {
    activityLogger.logActivity({ description: 'approve report', employeeId: 1 }, employees[0]);
    activityLogger.logActivity({ description: 'complete task', employeeId: 2 }, employees[1]);
    activityLogger.logActivity({ description: 'submit report', employeeId: 3 }, employees[2]);
} catch (error) {
    console.error(error.message);
}

console.log(activityLogger.getActivities());
