//Role Based Access Control System.
enum Role {
    Admin = "Admin",
    Editor = "Editor",
    Viewer = "Viewer"
}

interface Permission {
    Edit: boolean;
    View: boolean;
    Delete: boolean;
}

interface User {
    id: number;
    name: string;
    role: Role;
    permissions: Permission;
}

function checkPermission(user: User, requiredPermission: keyof Permission): boolean {
    return user.permissions[requiredPermission];
}

// Sample users
const adminUser: User = {
    id: 1,
    name: "Admin User",
    role: Role.Admin,
    permissions: {
        canEdit: true,
        canView: true,
        canDelete: true
    }
};

const editorUser: User = {
    id: 2,
    name: "Editor User",
    role: Role.Editor,
    permissions: {
        canEdit: true,
        canView: true,
        canDelete: false
    }
};

const viewerUser: User = {
    id: 3,
    name: "Viewer User",
    role: Role.Viewer,
    permissions: {
        canEdit: false,
        canView: true,
        canDelete: false
    }
};

// Test the permission logic
console.log(checkPermission(adminUser, 'canEdit')); // Output: true
console.log(checkPermission(editorUser, 'canDelete')); // Output: false
console.log(checkPermission(viewerUser, 'canView')); // Output: true

