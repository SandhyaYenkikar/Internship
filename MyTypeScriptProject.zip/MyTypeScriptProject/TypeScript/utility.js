"use strict";
// //Utility
// //Partial
// // interface User {
// //     id: number;
// //     name: string;
// //     email: string;
// // }
// // function updateUser(user: User, updates: Partial<User>): User {
// //     return { ...user, ...updates };
// // }
// // const user: User = { id: 1, name: "Sandhya", email: "sandhya@gmail.com" };
// // const updatedUser: User = updateUser(user, { id:2,email: "sandhyaaaaa@gmail.com" });
// // console.log(updatedUser);
// // console.log(user);
// // readonly 
// // //Function to update a user with possible partial updates, while keeping the original user object read-only
// // function updateUser(user: Readonly<User>, updates: Partial<User>): User {
// //     return { ...user, ...updates };
// // }
// // // Example usage
// // const user: Readonly<User> = { id: 1, name: "Sandhya", email: "sandhya@gmail.com" };
// // const updatedUser: User = updateUser(user, { id: 2, email: "sandhyaaaaa@gmail.com" });
// // console.log(updatedUser); 
// // console.log(user); 
// //pick
// // type UserPreview = Pick<User, "name" | "email">;
// // const userPreview: UserPreview = { name: "Sandhya", email: "sandhya@gmail.com" };
// // console.group(userPreview);
// // console.groupEnd();
// //omit
// // type UserWithoutEmail = Omit<User, "email">;
// // const userWithoutEmail: UserWithoutEmail = { id: 1, name: "Sandhya" };
// // console.log(userWithoutEmail); // Output: { id: 1, name: "Sandhya" }
// //type assertation
// // Using 'as' keyword
// // let value: unknown = "Hello, TypeScript!";
// // let strLength: number = (value as string).length;
// // console.log(strLength); 
// // // Using angle brackets <>
// // let value2: unknown = "Hello, TypeScript!";
// // let strLength2: number = (<string>value2).length;
// // console.log(strLength2); 
// //Narrowing Union Type
// // interface User{
// //     salary:number;
// //     name:string;
// // }
// // let userData:unknown={salary:"10000", name:"Sandhya",email:"sandhya@gmail.com"}
// // // let user=<User>userData;
// // // user.salary+=10;
// // let updatedSalary=(userData as User).salary;
// // console.log(typeof(updatedSalary));
// interface User {
//     salary: number;
//     name: string;
// }
// let userData: unknown = { salary: "10000", name: "Sandhya", email: "sandhya@gmail.com" };
// // Narrowing down the type of userData
// // if (typeof userData === 'object' && userData !== null && 'salary' in userData) {
// //     let user = userData as User;
// //     if (typeof user.salary === 'string') {
// //         user.salary = parseInt(user.salary, 10) + 10;
// //     }
// //     let updatedSalary = user.salary;
// //     console.log(updatedSalary); 
// //     console.log(typeof updatedSalary); 
// // }
// //Assertations
// let num: number = "123" as unknown as number;
// let someValue: unknown = "42";
// console.log((someValue as string).toUpperCase());
