
// Enum for roles
enum EmployeeRole {
    Manager,
    Developer,
    Designer,
    Tester,
    HR
}

// Interface for Employee
interface Employee {
    id: number;
    name: string;
    role: EmployeeRole;
    salary: number;
    isActive: boolean;
}

class EmployeeSystem {
    private employees: Employee[] = [];
    
    // Function to add a new employee
    addEmployee(employee: Employee): void {
        if (this.employees.some(e => e.id === employee.id)) {
            console.log(`Employee ${employee.id} already exists`);
        } else {
            this.employees.push(employee);
            console.log(`Employee ${employee.id} added successfully`);
        }
    }

    // Function to list all employees
    listAllEmployees(): Employee[] {
        return this.employees;
    }

    // Function to filter employees by role
    filterEmployeesByRole(role: EmployeeRole): void {
        const result = this.employees.filter(employee => employee.role === role);
        if (result.length) {
            console.log(`Employees in role ${EmployeeRole[role]}:`);
            result.forEach(employee => console.log(employee));
        } else {
            console.log(`No employees found in role ${EmployeeRole[role]}`);
        }
    }

    // Function to filter employees by status
    filterEmployeesByStatus(isActive: boolean): void {
        const result = this.employees.filter(employee => employee.isActive === isActive);
        if (result.length) {
            console.log(`Employees with status ${isActive ? "Active" : "Inactive"}:`);
            result.forEach(employee => console.log(employee));
        } else {
            console.log(`No employees found with status ${isActive ? "Active" : "Inactive"}`);
        }
    }

    // Function to update employee status
    updateEmployeeStatus(id: number, isActive: boolean): void {
        const employee = this.employees.find(emp => emp.id === id);
        if (employee) {
            employee.isActive = isActive;
            console.log(`Updated status of employee with ID ${id} to ${isActive ? "Active" : "Inactive"}.`);
        } else {
            console.log(`Employee with ID ${id} not found.`);
        }
    }

    // Function to calculate total salary
    calculateTotalSalary(): void {
        const totalSalary = this.employees.reduce((total, employee) => total + employee.salary, 0);
        console.log("Total Salary of all employees: " + totalSalary);
    }
}

const employeeManagementSystem = new EmployeeSystem();

// Adding employees
employeeManagementSystem.addEmployee({ id: 1, name: "Sandhya", role: EmployeeRole.Manager, salary: 95000, isActive: true });
employeeManagementSystem.addEmployee({ id: 2, name: "Rutuja", role: EmployeeRole.Developer, salary: 90000, isActive: true });
employeeManagementSystem.addEmployee({ id: 3, name: "Neha", role: EmployeeRole.Tester, salary: 50000, isActive: true });
employeeManagementSystem.addEmployee({ id: 4, name: "Misba", role: EmployeeRole.HR, salary: 95000, isActive: false });
employeeManagementSystem.addEmployee({ id: 5, name: "Prachi", role: EmployeeRole.Designer, salary: 85000, isActive: true });

// Listing all employees
employeeManagementSystem.listAllEmployees().forEach(employee => console.log(employee));

// Filtering employees by role
employeeManagementSystem.filterEmployeesByRole(EmployeeRole.Developer);

// Filtering employees by active status
employeeManagementSystem.filterEmployeesByStatus(true);

// Updating employee status
employeeManagementSystem.updateEmployeeStatus(5, false);
employeeManagementSystem.listAllEmployees().forEach(employee => console.log(employee));

// Calculating total salary
employeeManagementSystem.calculateTotalSalary();
