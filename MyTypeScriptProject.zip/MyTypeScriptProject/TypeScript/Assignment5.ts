// User Interface
interface User {
    id: number;
    name: string;
    role: 'admin' | 'manager' | 'employee';
}

// Permissions
const rolePermissions = {
    admin: ['view', 'edit', 'delete'],
    manager: ['view', 'edit'],
    employee: ['view'],
};

// Access Control Decorator 
function authorize(action: string) {
    return function (target: any, propertyKey: string, descriptor: PropertyDescriptor) {
        const originalMethod = descriptor.value;

        descriptor.value = function (...args: any[]) {
            const user: User = args[0];

            if (rolePermissions[user.role] && rolePermissions[user.role].includes(action)) {
                return originalMethod.apply(this, args);
            } else {
                console.error(`[Access Denied] User ${user.name} (Role: ${user.role}) is not allowed to ${action}`);
                return null;
            }
        };

        return descriptor;
    };
}

// Test Scenarios
class ReportActions {
    @authorize('view')
    viewReport(user: User) {
        console.log(`${user.name} is viewing the report.`);
    }

    @authorize('edit')
    editReport(user: User) {
        console.log(`${user.name} is editing the report.`);
    }

    @authorize('delete')
    deleteReport(user: User) {
        console.log(`${user.name} is deleting the report.`);
    }
}

// Test Cases
const adminUser: User = { id: 1, name: 'Sandhya', role: 'admin' };
const managerUser: User = { id: 2, name: 'Rutuja', role: 'manager' };
const employeeUser: User = { id: 3, name: 'Aishwarya', role: 'employee' };

const reportActions = new ReportActions();

reportActions.viewReport(adminUser);        
reportActions.editReport(adminUser);        
reportActions.deleteReport(adminUser);      

reportActions.viewReport(managerUser);      
reportActions.editReport(managerUser);      
reportActions.deleteReport(managerUser);    

reportActions.viewReport(employeeUser);     
reportActions.editReport(employeeUser);     
reportActions.deleteReport(employeeUser);   
