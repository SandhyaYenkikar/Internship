// const button = document.getElementById("btn") as HTMLButtonElement;

// const handleClick=(event:MouseEvent):void=>{
//     console.log("Button Clicked",event);
//     alert("you clicked the button");
// }

// button.addEventListener("click",handleClick);

// Mouse Events

// const div = document.createElement("div");
// div.style.width ="200px";
// div.style.height ="200px";
// div.style.background ="lightblue";
// document.body.appendChild(div);

// div.addEventListener("mouseenter",() =>{
//     div.style.backgroundColor ="lightgreen";
// });

// div.addEventListener("mouseleave",() =>{
//     div.style.backgroundColor ="lightblue";
// });

//keybord events
// document.addEventListener("keydown", (event: KeyboardEvent) => {
//     console.log('key pressed: ${event.key}');
// });

// document.addEventListener("keyup", (event: KeyboardEvent) => {
//     console.log('key released: ${event.key}');
// });

//formevent 
// const form = document.createElement("form");
// const input = document.createElement("input");
// const submitButton = document.createElement("button");

// submitButton.textContent = "Submit";
// form.appendChild(input);
// form.appendChild(submitButton);
// form.appendChild(form);

// input.addEventListener("input",(event:Event)=>{
//     const target = event.target as HTMLInputElement;
//     console.log(`Current input value: ${target.value}`);
// });
// form.addEventListener("submit",(event:Event)=>{
//     event.preventDefault ();
//     alert(`Form submitted with value: ${input.value}`);
// });

//Focus and blur Event
// const inputField = document.createElement("input");
// document.body.appendChild(inputField);

// inputField.addEventListener("focus",() => {
//     inputField.style.border = "2px solid green";
// });

// inputField.addEventListener("blur",() => {
//     inputField.style.border = "2px solid black";
// });

//Window Event

// window.addEventListener("resize",() => {
//     console.log('window size: ${window.innerWidth}x${window.innerHeight}');

// });

// window.addEventListener("scroll",() => {
//     console.log('scrolled to: ${window.scrollY}}');
// });








  
