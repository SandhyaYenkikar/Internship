// main.ts
import { MathOperations } from "./TypeGuards";

// Accessing members of the namespace
console.log(`Add: ${MathOperations.add(10, 5)}`);      // Output: Add: 15
console.log(`Subtract: ${MathOperations.subtract(10, 5)}`); // Output: Subtract: 5
