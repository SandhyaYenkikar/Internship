// Define the categories as an enum
enum Category {
    EventTarget,
    Electronics,
    Clothing,
    Grocery
}

// Define the product interface
interface Product {
    productName: string;
    price: number;
    isAvailable: boolean;
    category: Category;
}

// Create an array of products
const products: Product[] = [
   { productName: 'EventTarget1', price: 500, isAvailable: true, category: Category.EventTarget },
    { productName: 'Smartphone', price: 15000, isAvailable: true, category: Category.Electronics },
    { productName: 'T-Shirt', price: 500, isAvailable: false, category: Category.Clothing },
    { productName: 'Rice', price: 100, isAvailable: true, category: Category.Grocery }
];

// Display the product details in the console
products.forEach(product => {
    console.log(`Product Name: ${product.productName}`);
    console.log(`Price: ${product.price}`);
    console.log(`Available: ${product.isAvailable}`);
    console.log(`Category: ${Category[product.category]}`);
});
