//Enum for Employee Status
enum EmployeeStatus {
    Active,
    Inactive,
    Probation
}
//Interface for Employee
interface Employee {
    id: number;
    name: string;
    age: number;
    status: EmployeeStatus;
}
//Function to create an employee
function createEmployee(id:number, name:string, age:number, status:EmployeeStatus):Employee{
    return {id, name, age, status};
}
//Funcation to display employee details.
function displayEmployee (employee: Employee): void {
    console.log(`ID:${employee.id}`);
    console.log(`name:${employee.name}`);
    console.log(`age:${employee.age}`);
    console.log(`Employeestatus:${EmployeeStatus[employee.status]}`);
}
const emp1 = createEmployee(1,"Sandhya",21,EmployeeStatus.Active);
displayEmployee(emp1);