import { Injectable } from '@angular/core';
import { Task } from './task.model';

@Injectable({
  providedIn: 'root',
})
export class TaskService {
  private tasks: Task[] = [
    new Task(1, 'Task A', 'Pending', 'High'), new Task(2, "Task B","Pending","Low"), new Task(3,"Task C","Pending","Medium"), new Task(4, 'Task D', 'Pending', 'High'), new Task(5, "Task E","Pending","Low"), new Task(6,"Task F","Pending","Medium")];

  getTasks() {
    return this.tasks;
  }

  addTask(name: string, priority: 'Low' | 'Medium' | 'High') {
    const newTask = new Task(this.tasks.length + 1, name, 'Pending', priority);
    this.tasks.push(newTask);
  }

  updateTaskStatus(id: number, newStatus: 'Pending' | 'In Progress' | 'Completed') {
    const task = this.tasks.find(t => t.id === id);
    if (task) task.status = newStatus;
  }

  deleteTask(id: number) {
    this.tasks = this.tasks.filter(t => t.id !== id);
  }
}

