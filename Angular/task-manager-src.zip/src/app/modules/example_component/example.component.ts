import { Component } from "@angular/core";

@Component({
    selector:'app-example',
    standalone:false,
    templateUrl:'./example.component.html',
    styleUrl:'./example.component.css'
})

export class ExampleComponent{

}