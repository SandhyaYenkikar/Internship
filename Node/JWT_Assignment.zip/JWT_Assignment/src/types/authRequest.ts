export interface AuthRequest extends Request{
    user?:any;
}