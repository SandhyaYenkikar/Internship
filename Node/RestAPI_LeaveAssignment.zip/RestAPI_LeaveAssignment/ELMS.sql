CREATE TABLE tbl_Employees__Sandhya (
    id INT IDENTITY(1,1) PRIMARY KEY,
    name VARCHAR(40),
    email VARCHAR(40) UNIQUE,
    role VARCHAR(40) CHECK (role IN ('Employee','Manager','Admin'))
);

CREATE TABLE tbl_Leaves__Sandhya (
    id INT IDENTITY(1,1) PRIMARY KEY,
    employee_id INT FOREIGN KEY REFERENCES tbl_Employees__2(id),
    start_date DATE,
    end_date DATE,
    leave_type VARCHAR(20) CHECK (leave_type IN ('Sick', 'Vacation')),
    status VARCHAR(20) CHECK (status IN ('Pending', 'Approved', 'Rejected')) DEFAULT 'Pending',
    reason TEXT
);

INSERT INTO tbl_Employees__2 (name, email, role) VALUES ('Sandhya', 'sandhya@gmail.com', 'Manager');
INSERT INTO tbl_Employees__2 (name, email, role) VALUES ('Neha', 'neha@gmail.com', 'Employee');
INSERT INTO tbl_Employees__2 (name, email, role) VALUES ('Shrushti', 'shrushti@gmail.com', 'Admin');
INSERT INTO tbl_Employees__2 (name, email, role) VALUES ('Bob', 'bob@gmail.com', 'Employee');


select * from tbl_Leaves__Sandhya ;
select * from tbl_Employees__Sandhya ;