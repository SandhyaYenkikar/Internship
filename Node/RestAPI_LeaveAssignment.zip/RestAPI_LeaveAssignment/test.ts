console.log("Hello, TypeScript!");
