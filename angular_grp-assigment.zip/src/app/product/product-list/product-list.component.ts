import { Component } from '@angular/core';
import { ProductItem, ProductService } from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  standalone:false,
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent {
  products: ProductItem[] = [];

  constructor(private pservice: ProductService, private router: Router) {
    this.products = this.pservice.getProducts();
  }

  addProduct() {
    this.pservice.addnewProduct();
  }

  removeProduct(product: ProductItem) {
    this.pservice.removeProduct(product);
  }

  viewDetails(product: ProductItem) {
    this.router.navigate(['/productdetails', product.id]);
  }
}
