import express from "express";
import upload from "./multerConfig";
import { Request, Response } from "express";

const router=express.Router();

//POST Req to upload file
router.post('/upload', upload.single("file"), (req:Request, res:Response)=>{
  try{
    res.status(200).json({message:"file uploaded successfully!", file:req.file})
  }catch(error){
    res.status(500).json({error:"Unable to upload file"});
  }
});

export default router;



