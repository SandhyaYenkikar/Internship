import express from "express";
import router from "./routes";
import path from "path";

const app = express();

app.use('/jnc', router); //base path

//redirect to html page
app.get("/upload-form", (req, res) => {
    res.sendFile(path.join(__dirname, "upload.html"));
});

const PORT = 5000;
app.listen(PORT, () => {
    console.log(`server running on http://localhost:${PORT}`);
});